'''
Project Title - General Knowledge MCQ Console Application
Used Modules - None
Authors - Aditya Mishra,Adil Masood,Rahul M.S
Version - 1.0

'''

# loading questions, their options along with correct answers from .txt file
def load_questions_from_file(filename):
    questions = []
    with open(filename, 'r') as file:
        # Separate questions by newlines
        content = file.read().strip().split('\n\n')
        
        for block in content:
            lines = block.split('\n')
            question = lines[0]  # First line is the question
            options = lines[1:5]  # Next 4 lines are the options
            correct_answer = lines[5].split(': ')[1]  # The correct answer is after 'Answer: '
            
            # Add each question, options, and answer as a dictionary
            questions.append({
                "question": question,
                "options": options,
                "answer": correct_answer
            })
    
    return questions


def start_quiz():
    """
    Start the quiz by iterating through the loaded questions.
    """
    filename = 'MCQquestions.txt'  # Name of the file with questions and answers
    questions = load_questions_from_file(filename)
    
    score = 0
    user = input('Enter Your Name: ')
    print(f'''\t\t\t===================================
\t\t\t===================================
\t\t\t\t Hi {user}
\t\t\tWelcome to the General Knowledge Quiz!

\t\t\t======================================
\t\t\t===================================''')

    # Iterate over each question in the questions list
    for index, q in enumerate(questions):
        while True:  # Loop to keep the user on the same question if the input is invalid
            print(f"Question {index + 1}: {q['question']}")
            for option in q['options']:
                print(option)

            print('You can press 1 at any time if you want to Exit from the Quiz')
            # Get user input for the answer
            answer = input("Please choose your answer (a/b/c/d): ").lower()

            # If user wants to exit
            if answer == '1':
                print(f'''
\t\t\t===================================================================
\t\t\tThankYou for playing the Quiz,You've decided to exit the Quiz \n \t\t\t\t\t{user}!Your final score is: {score}/{len(questions)}\n
\t\t\t\tWe hope you enjoyed it!!!
\t\t\t================================================================''')
                return

            # Input validation for valid options and handling invalid input
            if answer in ['a', 'b', 'c', 'd']:  # If the input is valid
                if answer == q['answer']:
                    print("Correct!\n")
                    score += 1
                else:
                    print(f"Wrong! The correct answer was: {q['answer']}\n")
                break  # Exit the loop and move to the next question
            elif 'e' <= answer <= 'z' or '0' <= answer <= '9':  # If the input is invalid (e.g., 'e', 'f', 'g' etc.)
                print('''\n\n\t\t\tOops! You pressed an invalid input... try again.\n
                      *** You can press 1 anytime to exit or continue giving the quiz***\n''')
                continue  # Continue the loop and let the user reattempt the same question
            else:  # If input is not 'a', 'b', 'c', 'd' and not '1'
                print("\n\n\t\t\tOops! You pressed an invalid input... try again.\n")
                continue  # Continue the loop and let the user reattempt the same question

    # Final score after all questions
    print(f'''
\t\t\t=======================================
\t\t\t{user}, your final score is: {score}/{len(questions)}\n
\t\t\t\tHappy Learning...!!!
\t\t\t====================================''')


if __name__ == "__main__":
    start_quiz()
