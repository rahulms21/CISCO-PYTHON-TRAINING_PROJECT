import unittest

# load_questions_from_file from  module called mcq_quiz

from mcq_quiz import load_questions_from_file

class MytestCase(unittest.TestCase):
    def test_case_check(self):
        filename='MCQquestions.txt'
        questions=load_questions_from_file(filename)
        first_question=questions[0]
                           
        
    

if __name__ == '__main__':
    unittest.main()
